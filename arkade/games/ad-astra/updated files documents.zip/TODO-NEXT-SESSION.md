# Ad Astra - TODO List
## Next Session Priority Items

---

## 🔴 HIGH PRIORITY

### 🏴‍☠️ Pirate Encounters (BROKEN)
**Current state:** Pirates appear in log but nothing happens
**Needed:**
- [ ] Fight or Flee prompt dialog
- [ ] Combat sequence if player chooses to fight
- [ ] Flee mechanic (chance to escape based on ship speed)
- [ ] Boarding mechanic if ship disabled
- [ ] Cargo loss on defeat/boarding
- [ ] Pirate ship asset (player can create)
- [ ] Pirate captain intercom background (player can create)

### ⌨️ Command Input Bar (MISSING)
**Current state:** No way for player to type commands
**Needed:**
- [ ] Input bar above or integrated with Ship's Log
- [ ] Command parser for:
  - `warp #` or `goto #` - Travel to sector
  - `attack` - Attack enemy
  - `flee` - Run away
  - `scan` - Scan current sector
  - `dock` - Dock at station/planet
  - `help` - Show available commands
- [ ] Command history (up arrow)
- [ ] Auto-complete suggestions

### ❓ Help System (MISSING)
**Current state:** No help anywhere, players don't know what to do
**Needed:**
- [ ] Help button (?) on every screen
- [ ] Contextual help popups explaining:
  - What you can do on this screen
  - What buttons/controls do
  - Tips and strategies
- [ ] Main Game Guide accessible from menu
- [ ] Tutorial/First-time player walkthrough (optional)

---

## 🟡 MEDIUM PRIORITY

### 🛩️ Fighter Mechanics (UNCLEAR)
**Current state:** Players can deploy fighters but no feedback on what they do
**Needed:**
- [ ] Define fighter purpose:
  - Defend player in combat?
  - Patrol sector and attack enemies?
  - Ambush other players (PvP)?
- [ ] Fighter status display
- [ ] Fighter combat integration
- [ ] Help text explaining fighter mechanics

### 🗺️ Galaxy Map Warp (POSSIBLY BROKEN)
**Current state:** User reported clicking sectors doesn't warp
**Debug logging added:** Check console for `🗺️ Galaxy map click:` messages
**Needed:**
- [ ] Test and verify map clicking works
- [ ] Debug any issues found in console logs
- [ ] Ensure warp lane requirements are clear to player

### 🔄 Galaxy Regeneration Testing
**Current state:** Code updated but needs verification
**Needed:**
- [ ] Test full regeneration flow
- [ ] Verify all players reset to starting values
- [ ] Confirm contraband only at Black Markets after regen

---

## 🟢 LOWER PRIORITY

### 🎨 Assets Needed
- [ ] `assets/images/messageboard.webp` - Futuristic bulletin board scene
- [ ] Pirate ship image
- [ ] Pirate captain/intercom background
- [ ] Additional vendor images for variety

### 💰 Economy Balance
- [ ] Fighter price too low (50 credits) - increase?
- [ ] Review commodity prices
- [ ] Balance mining yields vs trading profits

### 🔧 Polish & Improvements
- [ ] 401 Unauthorized errors appearing - token refresh needed?
- [ ] Username pre-filling after database delete (investigate caching)
- [ ] Add more vendor dialogue variety
- [ ] Sound effects for more actions

---

## 📋 FEATURE IDEAS (FUTURE)

- [ ] Ship upgrades (better engines, cargo, shields)
- [ ] Missions/Quests system
- [ ] Reputation with factions
- [ ] Player-to-player trading
- [ ] Bounty hunting system
- [ ] Space stations players can own
- [ ] Alliances/Guilds

---

## 🧪 TESTING CHECKLIST

Before going live:
- [ ] Fresh player registration flow
- [ ] Complete gameplay loop (trade, travel, mine, combat)
- [ ] Multiplayer interactions
- [ ] Admin/Sysop functions
- [ ] All screens have working help
- [ ] Mobile responsiveness
- [ ] Performance with many players

---

*Created: November 24, 2024*
*Target: Playable alpha in ~1 week*
